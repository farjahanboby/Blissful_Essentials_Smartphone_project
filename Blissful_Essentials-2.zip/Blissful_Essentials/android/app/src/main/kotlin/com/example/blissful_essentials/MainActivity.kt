package com.example.blissful_essentials

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
